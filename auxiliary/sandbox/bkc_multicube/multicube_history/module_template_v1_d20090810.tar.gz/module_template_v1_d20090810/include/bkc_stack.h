/*************************************************************************
 *  copyleft(c)
 *************************************************************************
 *  module: bkc_stack
 *  file name: bkc_stack.h
 *  description: the basic string facility supplied in bkc
 *************************************************************************
 *  log:
 *  >>>
 *  version: 
 *      v1.0.1-v1.0.0
 *  time:
 *      Monday, May 18, 2009 at 12:35:01 AM AM UTC/GMT +8 hours
 *  location:
 *      Beijing, China on Earth
 *      latitude: 39.55 North, longtitude: 116.23 East 
 *      international country code: + 86 (China) 
 *      area code: 10
 *  wearther:
 *      clear, mild
 *      temperature: 82 F (comfort level is 81 F)
 *      wind: 1 mph from 0 North
 *
 *  pgr_id: sizhe(email:tancng#gmail.com)
 *
 *  description: created
 ************************************************************************/
#ifndef BKC_STACK_H
#define BKC_STACK_H

/*********************included files*************************************/

/*********************definition, types & constants ***********************/
/*ret value of funcs in bkc_stack*/
#define BKC_STACK_RET_SUC  (0)
#define BKC_STACK_RET_ERR  (-1)

#endif

