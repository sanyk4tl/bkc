/*************************************************************************
 *  copyleft(c)
 *************************************************************************
 *  module: bkc_modps
 *  file name: bkc_modps.h
 *  description: simplifed platform supporting of the bkc_modps mod
 *************************************************************************
 *  log:
 *  >>>
 *  version:
 *      v1.0.1-v1.0.0
 *  time:
 *      Monday, May 5, 2009 (090504) at 1:10:27 AM UTC/GMT +8 hours
 *  location:
 *      Beijing, China on Earth
 *      latitude: 39.55 North, longtitude: 116.23 East
 *      international country code: + 86 (China)
 *      area code: 10
 *  weather:
 *      clear, mild
 *
 *  pgr_id:sizhe(email:tancng#gmail.com)
 *
 *  description: created
 ************************************************************************/
#ifndef BKC_MODPS_H
#define BKC_MODPS_H
/*********************included files*************************************/

/*********************definition, types & constants ***********************/
/*define to open , undef or no define to close*/
/*releasing or debugging this module*/
#define BKC_MODPS_RELEASE

#if defined(BKC_MODPS_RELEASE)
/*trace file name and line when printf in this module*/
/*#define BKC_MODPS_FLPRT_OPEN*/
/*trace malloc*/
/*#define BKC_MODPS_MFPRT_OPEN*/
/*trace func return checking*/
#define BKC_MODPS_RETCKPRT_OPEN
/*trace debugging printf info in specific funcs*/
/*#define BKC_MODPS_DBUGPRT_OPEN*/
/*trace safe usage of pointers*/
/*#define BKC_MODPS_REFCHECK_OPEN*/
/*trace successfull return address in a func*/
/*#define BKC_MODPS_PRTSUCADDR_OPEN*/
#else
/*trace file name and line for general tracing printf in this module*/
#define BKC_MODPS_FLPRT_OPEN
/*trace malloc*/
#define BKC_MODPS_MFPRT_OPEN
/*trace func return checking*/
/*#define BKC_MODPS_RETCKPRT_OPEN*/
/*trace debugging printf info in specific funcs*/
#define BKC_MODPS_DBUGPRT_OPEN
/*trace safe usage of pointers*/
#define BKC_MODPS_REFCHECK_OPEN
/*trace successfull return address in a func*/
#define BKC_MODPS_PRTSUCADDR_OPEN
#endif

/*libc std func*/
#define BKC_MODPS_STD_PRINTF   printf
#define BKC_MODPS_STD_MEMSET   memset
#define BKC_MODPS_STD_MEMCPY   memcpy
#define BKC_MODPS_STD_STRNCPY  strncpy
#define BKC_MODPS_STD_STRNCMP  strncmp
#define BKC_MODPS_STD_STRCMP   strcmp
#define BKC_MODPS_STD_STRLEN   strlen
#define BKC_MODPS_STD_STRDUP   strdup
#define BKC_MODPS_STD_SPRINTF  sprintf
#define BKC_MODPS_STD_SNPRINTF snprintf
#define BKC_MODPS_STD_STRNCAT  strncat
#define BKC_MODPS_STD_MALLOC   malloc
#define BKC_MODPS_STD_FREE     free

/*libc std func used in bkc_modps module*/
/*printf utility*/
#define BKC_MODPS_TRFL \
    do {\
        BKC_MODPS_STD_PRINTF("[file:%s][line%d]", __FILE__, __LINE__);\
    } while (0)

/*general printing*/
#if defined(BKC_MODPS_FLPRT_OPEN)
#define BKC_MODPS_PRT \
    BKC_MODPS_TRFL; \
    BKC_MODPS_STD_PRINTF
#elif defined(BKC_MODPS_PRT_OPEN)
#define BKC_MODPS_PRT  0 ? ((void)0): BKC_MODPS_STD_PRINTF
#else
#define BKC_MODPS_PRT  1 ? ((void)0): BKC_MODPS_STD_PRINTF
#endif

/*for debugging info in a func*/
#if defined(BKC_MODPS_DBUGPRT_OPEN)
#define BKC_MODPS_DBGP  \
    BKC_MODPS_TRFL; \
    BKC_MODPS_STD_PRINTF
#else
#define BKC_MODPS_DBGP  0 ? ((void)0): BKC_MODPS_STD_PRINTF
#endif

/*for absolutely printing in a func*/
#define BKC_MODPS_ABSPRT BKC_MODPS_STD_PRINTF

/*for err-printing in a func*/
#define BKC_MODPS_ERR \
    BKC_MODPS_TRFL; \
    BKC_MODPS_STD_PRINTF("[error]");\
    BKC_MODPS_STD_PRINTF

/*for warn-printing in a func*/
#define BKC_MODPS_WARN \
    BKC_MODPS_TRFL;\
    BKC_MODPS_STD_PRINTF("[warn]");\
    BKC_MODPS_STD_PRINTF

#define BKC_MODPS_MEMSET    BKC_MODPS_STD_MEMSET
#define BKC_MODPS_MEMCPY    BKC_MODPS_STD_MEMCPY
#define BKC_MODPS_STRNCPY   BKC_MODPS_STD_STRNCPY
#define BKC_MODPS_STRNCMP   BKC_MODPS_STD_STRNCMP
#define BKC_MODPS_STRCMP    BKC_MODPS_STD_STRCMP
#define BKC_MODPS_STRLEN    BKC_MODPS_STD_STRLEN
#define BKC_MODPS_SPRINTF   BKC_MODPS_STD_SPRINTF
#define BKC_MODPS_SNPRINTF  BKC_MODPS_STD_SNPRINTF
#define BKC_MODPS_STRNCAT   BKC_MODPS_STD_STRNCAT

#if defined(BKC_MODPS_MFPRT_OPEN)
#define BKC_MODPS_MALLOC(param)  \
    bkc_modps_imalloc(param);\
    BKC_MODPS_TRFL;\
    BKC_MODPS_STD_PRINTF("(malloc position info)");\
    BKC_MODPS_STD_PRINTF("\n");

#define BKC_MODPS_MDPRT \
    BKC_MODPS_TRFL; \
    BKC_MODPS_STD_PRINTF

#define BKC_MODPS_FREE(param)  \
    bkc_modps_ifree(param);\
    BKC_MODPS_TRFL;\
    BKC_MODPS_STD_PRINTF("(free position info)");\
    BKC_MODPS_STD_PRINTF("\n");

#define BKC_MODPS_SFREE(param)  \
    do {\
        if ((param)) {\
            BKC_MODPS_FREE(param);\
            (param) = NULL;\
        }\
    } while(0);

#define BKC_MODPS_STRDUP(param)  \
    bkc_modps_istrdup(param);\
    BKC_MODPS_TRFL;\
    BKC_MODPS_STD_PRINTF("(dup position info)");\
    BKC_MODPS_STD_PRINTF("\n");

#else
#define BKC_MODPS_MALLOC(param)  bkc_modps_stdmalloc(param)
#define BKC_MODPS_FREE(param)  bkc_modps_stdfree(param)
#define BKC_MODPS_SFREE(param)  \
    do {\
        if ((param)) {\
            BKC_MODPS_FREE(param);\
            (param) = NULL;\
        }\
    } while(0);

#define BKC_MODPS_MDPRT  1 ? ((void)0): BKC_MODPS_STD_PRINTF

#define BKC_MODPS_STRDUP(param)  BKC_MODPS_STD_STRDUP(param)

#endif

/*ASTRET can be deactivated when released*/
#if 1
#define BKC_MODPS_ASTRET(cond, errnum, retval) \
    if (!(cond)) {\
         BKC_MODPS_TRFL;\
         BKC_MODPS_STD_PRINTF("assert failed:" #cond " is not satisfied\n");\
        (err_rlyflag) = (-1);\
        (terrno) = (errnum);\
        (fnret) = (retval);\
        break;\
    }
#else
#define BKC_MODPS_ASTRET(cond, ret) \
    do {\
        if (!(cond)) {\
            BKC_MODPS_ERR("assert failed, please have a check\n");\
            return (ret);\
        }\
    } while(0)

#define BKC_MODPS_ASTNRET(cond) \
    do {\
        if (!(cond)) {\
            BKC_MODPS_ERR("assert without retvalue failed, "\
                "please have a check\n");\
            return;\
        }\
    } while(0)
#endif

/*utilites for printing*/
#define BKC_MODPS_CKPRT(cond) \
    do {\
        if (!(cond)) {\
            BKC_MODPS_STD_PRINTF("[warn]please have a "\
                "check," #cond "is not satisfied\n");\
        }\
    } while(0)

/*specially for checking return value in a function,
  it is used when we only want the ret-checking for a special
  func without other CKPRT in the same function*/
#if defined(BKC_MODPS_RETCKPRT_OPEN)
#define BKC_MODPS_CKPRET(cond) \
    do {\
        if (!(cond)) {\
            BKC_MODPS_TRFL;\
            BKC_MODPS_STD_PRINTF("[error][func return],please "\
                "have a check," #cond "is not satisfied\n");\
        }\
    } while(0)
#else
#define BKC_MODPS_CKPRET(cond) \
    do {\
        if (!(cond)) {\
        }\
    } while(0)
#endif

/*utilities for array initialization*/
#define BKC_MODPS_SETARR(array, loop, scanstart, scanlen, defval) \
    do {\
        if ( ( (array) != NULL)) {\
            for ( (loop) = (scanstart); (loop) < \
                ( (scanlen) + (scanstart)); (loop)++) {\
                (array)[(loop)] = (defval);\
            }\
        }\
    } while(0)

/*normal ret value of funcs in bkc_modps*/
#define BKC_MODPS_RSUC  (0)
#define BKC_MODPS_RERR  (-1)

/*compiler*/
#define BKC_MODPS_COMPILER_GCC

/*magic value for not initialized memory, just be helpfull
    to trace down when debugging*/
#if defined(BKC_MODPS_RELEASE)
#define BKC_MODPS_MAGIC_STUFF 0x33
#else
#define BKC_MODPS_MAGIC_STUFF 0x00
#endif

/*utilities for declaring a user defined structure*/
#if defined(BKC_MODPS_COMPILER_GCC)
#define BKC_MODPS_DCL(name, type)    \
    type name;\
    BKC_MODPS_MEMSET(&(name), BKC_MODPS_MAGIC_STUFF, sizeof(type));
#else
#define BKC_MODPS_DCL(name, type)    \
    type name;
#endif

/*utilities for try catch style*/
/*check and throw error*/
/*declaration and initilation for try and throw styles*/
#define BKC_MODPS_DITT(infnret, interrno)  \
    /*successfull running status for this func*/ \
    int fnbegline = __LINE__; \
    char *fnfile_p = __FILE__; \
    int sucfnret = infnret; \
    /*real ret for this func*/ \
    int fnret = infnret; \
    /*ret for checking funcs*/ \
    int ckret = 0; \
    /*thrown err*/ \
    int terrno = interrno; \
    /*error relay flag*/ \
    int err_rlyflag = 0; \
    /*control the try area*/ \
    int try_flag = 0

#define BKC_MODPS_CKRET ckret
#define BKC_MODPS_FNRET fnret

/*failed abnormity*/
#define BKC_MODPS_FABN (NULL)

/*check condition,  set error relay flag, and throw error*/
#define BKC_MODPS_CKTHROW(cond, errnum, retval) \
    if (!(cond)) {\
         BKC_MODPS_TRFL;\
         BKC_MODPS_STD_PRINTF("" #cond " is not satisfied\n");\
        (err_rlyflag) = (-1);\
        (terrno) = (errnum);\
        (fnret) = (retval);\
        break;\
    }

/*check condition, print reason, set error relay flag, and throw error*/
#define BKC_MODPS_CKSTHROW(cond, errnum, retval, reason_str) \
    if (!(cond)) {\
        BKC_MODPS_TRFL;\
        BKC_MODPS_STD_PRINTF("" #cond " is not satisfied\n");\
        if (!(reason_str)) {\
            BKC_MODPS_STD_PRINTF(reason_str);\
        }\
        (err_rlyflag) = (-1);\
        (terrno) = (errnum);\
        (fnret) = (retval);\
        break;\
    }

/*directly set error relay flag, and throw error*/
#define BKC_MODPS_ERRTHROW(reason_str, errnum, retval) \
    BKC_MODPS_TRFL;\
    if (!(reason_str)) {\
        BKC_MODPS_STD_PRINTF(reason_str);\
    }\
    (err_rlyflag) = (-1);\
    (terrno) = (errnum);\
    (fnret) = (retval);\
    break;

/*directly set successful ret value, and return*/
#if defined(BKC_MODPS_PRTSUCADDR_OPEN)
#define BKC_MODPS_SUCRET(retval) \
    BKC_MODPS_TRFL;\
    (err_rlyflag) = (-1);\
    (fnret) = (retval);\
    break;
#else
#define BKC_MODPS_SUCRET(retval) \
    (err_rlyflag) = (-1);\
    (fnret) = (retval);\
    break;
#endif


/*relay the throwed error*/
#define BKC_MODPS_RLYTHROW() \
    if ((err_rlyflag) != (0)) {\
        break;\
    }

/*return*/
#define BKC_MODPS_RETURN(ret) \
    BKC_MODPS_CKPRET((fnret) == (sucfnret));\
    return ret;

#define BKC_MODPS_TRY  for (try_flag = 0; try_flag == 0; try_flag = -1)
#define BKC_MODPS_BREAK  break
#define BKC_MODPS_CATCH  switch (terrno)
#define BKC_MODPS_CASE(param)  case (param):
#define BKC_MODPS_DEFAULT      default :

/*get a valid string, usefull for printf */
#define BKC_MODPS_GETVSTR(param)  ( (param) == NULL || \
    (*(param) == '\0') ? "EMPTY" : (param))

/*short names for the above utilites used in bkc_modps*/
/*for reference of pointer*/
#if defined(BKC_MODPS_REFCHECK_OPEN)
#define BKC_RF(pointer) ( ( (pointer) == NULL ? \
    (BKC_MODPS_STD_PRINTF("" #pointer " is null\n" \
    "[func beginning line] is %d\n"\
    "[file] %s\n", fnbegline, fnfile_p), (pointer)) \
    : (pointer)))
#else
#define BKC_RF(pointer) (pointer)
#endif
#define BKC_MSTUFF    BKC_MODPS_MAGIC_STUFF

#define BKC_MEMSET    BKC_MODPS_MEMSET
#define BKC_MEMCPY    BKC_MODPS_MEMCPY
#define BKC_STRNCPY   BKC_MODPS_STRNCPY
#define BKC_STRNCMP   BKC_MODPS_STRNCMP
#define BKC_STRCMP    BKC_MODPS_STRCMP
#define BKC_STRLEN    BKC_MODPS_STRLEN
#define BKC_SPRINTF   BKC_MODPS_SPRINTF
#define BKC_SNPRINTF  BKC_MODPS_SNPRINTF
#define BKC_STRNCAT   BKC_MODPS_STRNCAT
#define BKC_STRDUP    BKC_MODPS_STRDUP

#define BKC_PRT       BKC_MODPS_PRT
#define BKC_DBGP      BKC_MODPS_DBGP
#define BKC_ABSPRT    BKC_MODPS_ABSPRT
#define BKC_ERR       BKC_MODPS_ERR
#define BKC_WARN      BKC_MODPS_WARN

#define BKC_MALLOC    BKC_MODPS_MALLOC
#define BKC_MDPRT     BKC_MODPS_MDPRT
#define BKC_FREE      BKC_MODPS_FREE
#define BKC_SFREE     BKC_MODPS_SFREE

#define BKC_ASTRET    BKC_MODPS_ASTRET
#define BKC_CKPRT     BKC_MODPS_CKPRT
#define BKC_CKPRET    BKC_MODPS_CKPRET

#define BKC_DITT      BKC_MODPS_DITT
#define BKC_RETURN    BKC_MODPS_RETURN

/*flow control utilities*/
#define BKC_FLOWCONTROL_TRY       BKC_MODPS_TRY
#define BKC_FLOWCONTROL_CATCH     BKC_MODPS_CATCH
#define BKC_FC_BREAK              BKC_MODPS_BREAK
#define BKC_FC_CASE               BKC_MODPS_CASE
#define BKC_FC_DEFAULT            BKC_MODPS_DEFAULT
#define BKC_FC_CKTHR              BKC_MODPS_CKTHROW
#define BKC_FC_CKSTHR             BKC_MODPS_CKSTHROW
#define BKC_FC_ERRTHR             BKC_MODPS_ERRTHROW
#define BKC_FC_SUCRET             BKC_MODPS_SUCRET
#define BKC_FC_RLYTHR             BKC_MODPS_RLYTHROW

#define BKC_CKRET     BKC_MODPS_CKRET
#define BKC_FNRET     BKC_MODPS_FNRET
#define BKC_FABN      BKC_MODPS_FABN

#define BKC_SETARR   BKC_MODPS_SETARR
#define BKC_GETVSTR   BKC_MODPS_GETVSTR

/*for memory diagnose*/
typedef void *(*bkc_modps_malloc_func_t)(unsigned int);
typedef void (*bkc_modps_free_func_t)(void *mem_p);
/*********************prototype of open functions************************/
/*************************************************************************
 *                  bkc_modps_resetmm
 *************************************************************************
 * parameters:
 * return value:
 * description:
 *     reset the memory record status, can be called before each
 *     diagnose
 *****************************  Notes  *****************************
 ************************************************************************/
int bkc_modps_resetmm(void);

/*************************************************************************
 *                  bkc_modps_imalloc
 *************************************************************************
 * parameters:
 * return value:
 * description:
 *     pseudo malloc
 *****************************  Notes  *****************************
 ************************************************************************/
void *bkc_modps_imalloc(unsigned int size);

/*************************************************************************
 *                  bkc_modps_ifree
 *************************************************************************
 * parameters:
 * return value:
 * description:
 *     pseudo free
 *****************************  Notes  *****************************
 ************************************************************************/
int bkc_modps_ifree(void *p);

/*************************************************************************
 *                  bkc_modps_istrdup
 *************************************************************************
 * parameters:
 * return value:
 * description:
 *     pseudo strdup
 *****************************  Notes  *****************************
 ************************************************************************/
void *bkc_modps_istrdup(char *str_p);

/*************************************************************************
 *                  bkc_modps_watchmm
 *************************************************************************
 * parameters:
 * return value:
 * description:
 *     called to watch the current memory status
 *****************************  Notes  *****************************
 ************************************************************************/
int bkc_modps_watchmm(void);

/*************************************************************************
 *                  bkc_modps_memdgn
 *************************************************************************
 * parameters:
 * return value:
 * description:
 *     called to diagnose the current memory status
 *****************************  Notes  *****************************
 ************************************************************************/
void bkc_modps_memdgn(bkc_modps_malloc_func_t malloc_func,
        bkc_modps_free_func_t free_func);

/*************************************************************************
 *                  bkc_modps_stdmalloc
 *************************************************************************
 * parameters:
 * return value:
 * description:
 *     use to replace the standard malloc, and will stuff the magic num
 *     for each malloc blocks
 *****************************  Notes  *****************************
 ************************************************************************/
void *bkc_modps_stdmalloc(unsigned int size);


/*************************************************************************
 *                  bkc_modps_stdfree
 *************************************************************************
 * parameters:
 * return value:
 * description:
 *     paired with the bkc_modps_stdmalloc
 *****************************  Notes  *****************************
 ************************************************************************/
int bkc_modps_stdfree(void *p);

#endif

