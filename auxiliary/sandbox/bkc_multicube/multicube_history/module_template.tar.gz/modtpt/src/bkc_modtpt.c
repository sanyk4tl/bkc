/*************************************************************************
 *  copyleft(c)
 *************************************************************************
 *  module: bkc_modtpt
 *  file name: bkc_modtpt.c
 *  description: templation for adding a new model
 *************************************************************************
 *  log:
 *  >>>
 *  version: 
 *      mv0.0.1-sv0.0.1
 *  time:
 *      Thursday, April 16, 2009 (090416) at 12:45:07 AM UTC/GMT +8 hours
 *  location:
 *      ChongQing, China on Earth
 *      latitude: 29.3 North, longtitude: 106.35 East 
 *      international country code: + 86 (China) 
 *      area code: 23
 *  wearther:
 *      clear, mild
 *      temperature: 70 F (comfort level is 70 F)
 *      wind: 3 mph from 190 south by west
 *
 *  pgr_id:sizhe(email:tancng#gmail.com)
 *
 *  description: created
 ************************************************************************/
/*********************included files*************************************/
#include <stdlib.h>
#include <stdio.h>
#include "bkc_modtpt.h"
#include "bkc_modtpt_spf.h"

/*********************definition, constant & types***********************/

/*********************variables******************************************/

/*********************prototype of local functions***********************/

/*********************implementation of open and local functions*********/

