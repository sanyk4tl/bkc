/****************************************************************************
 *  copyleft(c)
 ****************************************************************************
 *  module: bkc_template
 *  file name: bkc_template.c
 *  description: simplifed platform supporting of the bkc_template mod
 ****************************************************************************
 *  log:
 *  >>>
 *  version:
 *      v1.0.1-v1.0.0
 *  time:
 *      Monday, May 5, 2009 (090504) at 1:10:27 AM UTC/GMT +8 hours
 *  location:
 *      Beijing, China on Earth
 *      latitude: 39.55 North, longtitude: 116.23 East
 *      international country code: + 86 (China)
 *      area code: 10
 *  weather:
 *      clear, mild
 *
 *  pgr_id:sizhe(email:tancng#gmail.com)
 *
 *  description: created
 ***************************************************************************/
/*********************included files****************************************/

/*********************definition, types & constants ************************/

/*********************variables*********************************************/

/*********************prototype of local functions**************************/

/*********************implementation of open and local functions************/
/****************************************************************************
 *                  bkc_template_imalloc
 ****************************************************************************
 * parameters:
 * return value:
 * description:
 *     commented
 ***************************** notes *************************************
 ***************************************************************************/

